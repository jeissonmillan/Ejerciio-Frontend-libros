package co.edu.poli.act3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
